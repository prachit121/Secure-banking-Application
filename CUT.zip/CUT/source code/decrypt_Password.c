#include "bank.h"
#include <stdio.h>
#include <string.h>
void decrypt_Password(char password[]) // pass the password to this function
{
    
    FILE *fptr = fopen("pass.txt","a");
    for(int i=0; i< strlen(password); i++)
    {
        password[i] = password[i] - 2;
    }
	fprintf(fptr," %s", password);
	fclose(fptr);
   
    return;

}