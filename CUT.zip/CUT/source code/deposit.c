#include<stdlib.h>
#include<string.h>
#include "bank.h"
#include<stdio.h>

void deposit(char uname[])
{
    double dep_amt;
    FILE *ftranact;
    FILE *fu;
    FILE *fp;
    char utranact[SIZE]=" ";
    char tranactFile[SIZE]=" ";
    double balance = 0;

    printf("Enter the amount to be deposited : \n");
    scanf("%lf",&dep_amt);
    strcpy(tranactFile,uname);
    strcat(tranactFile,"Transaction.dat");
    ftranact=fopen(tranactFile,"r");
    if(ftranact == NULL)
    {
        printf("Error opening file %s\n", tranactFile);
        exit(1);
    }
    // reading the previously stored balance
    fread(&balance , sizeof(double), 1, ftranact);
    fclose(ftranact);
    
    balance = balance + dep_amt;
    printf("Total balance after depositing %lf is %lf", dep_amt, balance); 
    
    ftranact=fopen(tranactFile,"w");
    if(ftranact == NULL)
    {
        printf("Error opening file %s\n", tranactFile);
        exit(1);
    }
    // writing the updated balance to the file
    fwrite(&balance, sizeof(double), 1, ftranact);
    fclose(ftranact);
    
    fu=fopen("allTransactions.dat","a");
    if(fu == NULL)
    {
        printf("Error opening file allTransactions.dat\n");
        exit(1);
    }
    // writing to the file that amount is deposited
    fprintf(fu,"%s  deposited %lf amount\n", uname, dep_amt);
    fclose(fu);
    
    strcpy(utranact, uname);
    strcat(utranact, "passbook.dat");
    
    fp=fopen(utranact,"a");
    if(fp == NULL)
    {
        printf("Error opening file %s\n", utranact);
        exit(1);
    }
    // writing to the user passbook that amount is deposited
    fprintf(fp, "%lf is deposited\n", dep_amt);
    fclose(fp);
    
    return;
}