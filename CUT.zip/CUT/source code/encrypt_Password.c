#include "bank.h"
#include <stdio.h>
#include <string.h>
void encrypt_Password(char password[]) // pass the password to this function
{
    
    FILE *fptr = fopen("pass.txt","a");
    for(int i=0; i< strlen(password); i++)
    {
        password[i] = password[i] + 2;
        // password = "ABCD" & i=0
        // password[i] (A) = password[i] (A) + 2;
        // password = "CDEF"
    }
	fprintf(fptr," %s", password);
	fclose(fptr);
   
    return;

}