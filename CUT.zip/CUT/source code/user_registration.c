#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include "bank.h"
 
 
void register_user()
{
    
    char name[50];
    char Lastname[50];
    int phone[50];
    int age;
    
    printf("Register to Create An Account:\n");
    printf("Enter First name: ");
    scanf(" %s", name);
    printf("Enter Last name: ");
    scanf(" %s", Lastname);
    //fgets(name ,199, stdin);
    printf("Enter phone number: ");
    scanf("%d",phone);
    printf("Enter age: ");
    scanf("%d",&age);
    if (age <= 18) 
    {                                                //Error: Age must be 18 or older to register.\n");
        printf("Sorry You are not Eligible to Open an Account.\n");
        register_user();
    } else {
        printf("User registered successfully.\n");
    }
    
    return ;
}