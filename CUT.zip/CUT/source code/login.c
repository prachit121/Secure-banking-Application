//Including necessary header
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include "bank.h"

void login(char username[],char password[])
{
	//Variable declaration
    int ch;
    FILE *fptr;
    char username1[50],password1[50];
	double amount=0;
	struct pass u1;
	struct userpassword p1;
    //int whileIsTrue = 1;
        printf("Enter the username:");
    	scanf(" %s",username1);
    	printf("Enter the password:");
    	scanf(" %s",password1);

    	fptr = fopen("pass.txt", "r");
    	char tempLine[100];
    	while(fgets(tempLine, 100, fptr))
    	{
    	    char *tok = strtok(tempLine, ",");
    	    if(strcmp(tok, username1) == 0)
    	    {
    	        tok = strtok(NULL, ",");
    	        int lastChar = strlen(tok);
    	        lastChar = lastChar - 1;
    	        tok[lastChar] = '\0';
    	        if(strcmp(tok, password1) == 0)
    	        {
    	            printf("                                   ** Login Successful **               \n");
    	            break;
    	        }
    	        else
    	        {
    	            printf("Invalid Credentials \n");
    	            login(username, password);
    	        }
    	    }
    	}
    	
    	
    	/*fu=fopen("pass.txt","r");
    	if(fu==NULL)
    	{
    	    printf("File Not Found\n");
    	    exit(0);
    	}
    	while(fscanf(fu,"%s%s",u1.username,p1.password)!=EOF)
    	{
    	    if(strcmp(username1,u1.username)==0 && strcmp(password1,p1.password)==0)
    	{
    	
    	*/
    	
    
	while(1)
	{
		//Banking system option displayed to the user
	    printf("\t\tBANKING SYSTEM\n");
        printf("\t\t 1. Withdraw\n\t\t 2. Balance Check\n\t\t 3. Edit Details or set new password\n\t\t 4. deposit\n\t\t 5.Signout\n");
	
	//Taking the choice from the user
        printf("Enter the option:\n");
        scanf("%d", &ch);
	
	//Switch the cases according to the user option
        switch(ch)
        {
		    case 1: printf("Enter the amount to withdraw : ");
			        scanf(" %lf", &amount);
			        withdraw(username1, amount);
                        break;
            case 2: checkBalance(username1);
                        break;
            case 3: editDetails(username1);
                        break;
            case 4: deposit(username1);
                        break;
		    case 5: return;
        }
	}
}
 //}
//}
//fclose(fu);
//}
   	   	

